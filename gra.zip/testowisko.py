import os
import random
import pyautogui
import pygame

"""for jungle_photo in os.listdir("Assets/jungle_photos"):
    print(jungle_photo[:-4])

x = random.choice(os.listdir("Assets/jungle_photos"))[:-4]
print(x)

with open("Assets/interesting_facts/"+x+".txt", "r", encoding="utf-8") as f:
    tresc_notatki = f.read().replace('\n','')
tresc_notatki = 'Gratulacje!\n'+tresc_notatki+'\nCzy chcesz rozwiązać kolejną zagadkę?'
"""


"""if pyautogui.confirm('notatka ciekawa',"zwyciestwo",['kolejna gra','dosc!']) == 'kolejna gra':
    x = pyautogui.confirm("wybierz poziom trudności",'menu',['banalny','łatwy','trudny'])
    if x == 'banalny':
        print('beksa')
    elif x == 'łatwy':
        print('ok')
    else:
        print('kozak')
else:
        print('wybrales dosc')
"""

"""def main(n,m):
    for i in range(n):
        print(n)
    if m==1:
        print('banal')


main(10,1)
print('stop \n')
print(4,)
"""
# Starting the mixer
pygame.mixer.init()

ew = pygame.mixer.Sound('eww.mp3')
ew.play()
d
